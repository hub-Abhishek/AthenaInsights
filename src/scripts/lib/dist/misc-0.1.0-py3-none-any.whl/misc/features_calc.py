import pandas as pd
import numpy as np

def calc():
    pass