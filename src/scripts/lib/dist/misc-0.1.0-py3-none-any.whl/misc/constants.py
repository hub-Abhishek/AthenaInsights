symbols = [
    'SPY', 'QQQ', 'VIX', 'DJI', 'IXIC', 'RUT', 
    'UKX', 'DAX', 'NTETF', 'HSXUF' # 'CAC 40'
    'GBP']